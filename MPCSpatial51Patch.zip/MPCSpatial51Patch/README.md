# MPCSpatial51: experimental Windows Spatial Sound output for MPC-HC (source patch)

**Status: source-level prototype, NOT a tested Windows executable.**

This patch adds an opt-in `ISpatialAudioClient` renderer **to the SaneAR component of MPC-HC**, allowing 5.1(side) PCM to be submitted as six static speaker-channel objects to the *active Windows spatial-audio provider*. If the selected provider in Windows is **Dolby Atmos for Headphones**, that is the provider Windows should use to render the objects to stereo headphones. This does **not** add an Atmos decoder or object metadata to DTS-HD MA. It provides channel-based 5.1 virtual surround.

**Important:** In MPC-HC's `Options > Playback > Output > Audio Renderer`, choose **SaneAR Audio Renderer**, **NOT MPC Audio Renderer**. They are distinct projects. A previous draft targeted SaneAR; this package is explicitly scoped to that backend and does not pretend to change the separate MPC Audio Renderer.

The source code was checked against the `develop` branch of `clsid2/mpc-hc` accessed on November 12, 2026. The Linux-based authoring environment cannot build/test Windows C++ code or exercise a Dolby endpoint. Build and runtime validation on Windows are still required before treating this as functional. Do not install it over your existing working player until it passes those tests.

## What the patch does

- Keeps MPC-HC's existing LAV DTS-HD Master Audio decoding untouched.
- Adds a custom audio device using the documented Windows `ISpatialAudioClient` and `ISpatialAudioObjectRenderStream` APIs.
- Creates **six static audio objects** representing Front Left, Front Right, Front Center, LFE, Side Left and Side Right.
- Converts six-channel 32-bit float interleaved PCM into six mono spatial-object buffers, with no prior binauralization or stereo downmix by the device.
- Preserves SaneAR's existing clock/synchronization abstraction via `IAudioClock` obtained from `ISpatialAudioObjectRenderStream::GetService`.
- Emits debug messages that can establish whether the spatial API was actually activated and whether an audio buffer was committed.
- Tries spatial audio only when `MPC_SPATIAL_51=1` and the source is **exactly 48,000 Hz, six channels, 0x60F channel layout (5.1 with side surrounds)**, shared mode, crossfeed disabled. All other audio uses the original renderer.
- Falls back to the existing WASAPI path if creating the spatial stream fails. An error *during* streaming stops the device; the player may need to be restarted without the opt-in flag.

## Requirements

- Windows 10/11 with a Windows Spatial Sound endpoint, preferably Windows 11.
- Dolby Atmos for Headphones already enabled under the desired headphone endpoint's `Spatial sound` settings.
- Visual Studio 2022 with C++ desktop development, ATL/MFC and current Windows 10/11 SDK; dependencies required by the MPC-HC project.
- Python 3 to apply the patch (not needed to run the resulting application).
- Access to the original [MPC-HC repository](https://github.com/clsid2/mpc-hc), branch `develop`.

## 1. Clone and apply

From PowerShell:

```powershell
git clone --branch develop --recurse-submodules https://github.com/clsid2/mpc-hc.git C:\mpc-hc-spatial

# Extract this ZIP somewhere, e.g. C:\Users\YourUser\Downloads\MPCSpatial51Patch
python "C:\Users\YourUser\Downloads\MPCSpatial51Patch\apply_patch.py" "C:\mpc-hc-spatial" --dry-run
python "C:\Users\YourUser\Downloads\MPCSpatial51Patch\apply_patch.py" "C:\mpc-hc-spatial"
```

The patcher backs up modified files as `*.pre-spatial51`, checks source anchor matches, and refuses to overwrite an existing patch. The new source files are placed under `src/thirdparty/sanear/src/`.

## 2. Build

Follow the [upstream MPC-HC compilation guide](https://github.com/clsid2/mpc-hc/blob/develop/docs/Compilation.md), including its Visual Studio workload and dependencies.

Open `C:\mpc-hc-spatial\mpc-hc.sln` in Visual Studio, choose `Release | x64`, and build the solution (F7). Alternatively follow the upstream build.bat instructions. The built executable should be under `C:\mpc-hc-spatial\bin\mpc-hc_x64\mpc-hc64.exe`.

**No compiled Windows binary is included**: a Windows build and real-device testing are outstanding. This package is not a release-quality patch and may require compiler/API adjustments.

## 3. Run without changing your existing installation

In the *same* PowerShell session, before launching the newly built MPC-HC:

```powershell
$env:MPC_SPATIAL_51 = "1"
& "C:\mpc-hc-spatial\bin\mpc-hc_x64\mpc-hc64.exe"
```

Then configure the **newly built** player:

1. `View > Options > Playback > Output > Audio Renderer` -> **SaneAR Audio Renderer**. (Do not choose MPC Audio Renderer.)
2. Open the settings for **SaneAR**. Choose your `Headphones (TE-C)` endpoint, **shared mode**; turn crossfeed off.
3. In Windows Sound Settings for `Headphones (TE-C)`, enable **Dolby Atmos for Headphones** and leave the headphone output at 48 kHz.
4. Keep LAV bitstreaming **off** and mixing **off**.
5. Open the remuxed movie, choose the DTS-HD MA **5.1** track.
6. Test with the supplied `tests/5.1-side-channel-test.wav` for FL, FR, C, LFE, SL, SR sequentially. The test is nonverbal tones, each channel a different pitch; it is not a definitive positional calibration.

If your application is already running before the variable is set, the variable will **not** take effect. Restart the player from that PowerShell session.

## 4. Verify the processing, not just the toggle

Use Microsoft's Sysinternals [DebugView](https://learn.microsoft.com/en-us/sysinternals/downloads/debugview) to capture `OutputDebugStringW` messages. Filter for `MPCSpatial51`.

Expected source-level diagnostics, if the spatial path succeeds:

```
[MPCSpatial51] ISpatialAudioClient stream ACTIVATED (5.1 static bed)
[MPCSpatial51] spatial renderer created; six static channels selected
[MPCSpatial51] first 5.1 spatial buffer committed to Windows
```

These would establish **a spatial stream was created and six static object buffers were submitted to Windows**. They do **not**, by themselves, identify the particular installed provider (Dolby vs Windows Sonic), prove subjective front/back positioning, or certify an end-to-end audio trace. You separately verify that Windows selects Dolby Atmos for Headphones for this endpoint.

If you see `unavailable; falling back to normal WASAPI`, spatial stream initialization failed. In that case the player must **not** be treated as a successful surround spatial-rendering test, even if it still plays sound.

## 5. Disable / revert

The easy switch: close the player, open it without the variable, or set `$env:MPC_SPATIAL_51 = "0"` before launching. The original SaneAR code path remains available. Your existing installed MPC-HC is completely unaffected.

To undo the source patch, restore the four `*.pre-spatial51` backups and delete the two added `AudioDeviceSpatial` files, or use a fresh clone.

## Technical limitations / missing work

- **Experimental/uncompiled:** The integration needs a real Windows compiler run and audio test. No claim is made that the supplied source builds cleanly or plays perfectly on your system.
- Only the **48 kHz, side-surround 5.1** layout (`0x60F`) is attempted. Other layouts, higher channel counts, stereo and compressed bitstream input use existing playback.
- A real product needs a GUI checkbox (this uses an environment variable), automated tests, device hot-swap recovery, more rigorous clock jitter handling, checks of buffer underruns and optional support for other sample rates/layouts.
- The intended provider is whichever one Windows spatial sound chooses. The patch does not name a Dolby API or independently attest a Dolby processing stage.
- This is **not** an object-based Atmos decoder. DTS-HD MA remains channel-based DTS audio.
- The test WAV intentionally has no normalization, compressor or additional HRTF. Actual loudness still depends on film mastering.
- License: work intended as a GPLv3-compatible patch to the GPL-licensed MPC-HC source. Consult upstream's `COPYING.txt` for redistribution terms.

## Primary references

- [MPC-HC / SaneAR AudioDeviceManager.cpp](https://github.com/clsid2/mpc-hc/blob/develop/src/thirdparty/sanear/src/AudioDeviceManager.cpp)
- [MPC-HC compilation instructions](https://github.com/clsid2/mpc-hc/blob/develop/docs/Compilation.md)
- [Microsoft: Render spatial sound using spatial audio objects](https://learn.microsoft.com/en-us/windows/win32/coreaudio/render-spatial-sound-using-spatial-audio-objects)
- [Microsoft: ISpatialAudioObjectRenderStreamBase::GetService (IAudioClock)](https://learn.microsoft.com/en-us/windows/win32/api/spatialaudioclient/nf-spatialaudioclient-ispatialaudioobjectrenderstreambase-getservice)
- [Microsoft: ISpatialAudioClient::GetNativeStaticObjectTypeMask](https://learn.microsoft.com/en-us/windows/win32/api/spatialaudioclient/nf-spatialaudioclient-ispatialaudioclient-getnativestaticobjecttypemask)
