#pragma once

// Experimental Windows Spatial Sound output device for MPC-HC's sanear renderer.
// Accepts 48 kHz float 5.1 (side surround) and sends six independent static
// spatial audio objects. The Windows spatial provider then renders to headphones.

#include "AudioDevice.h"
#include <mutex>

namespace SaneAudioRenderer
{
    class AudioDeviceSpatial final : public AudioDevice
    {
    public:
        explicit AudioDeviceSpatial(std::shared_ptr<AudioDeviceBackend> backend);
        ~AudioDeviceSpatial() override;
        AudioDeviceSpatial(const AudioDeviceSpatial&) = delete;
        AudioDeviceSpatial& operator=(const AudioDeviceSpatial&) = delete;

        void Push(DspChunk& chunk, CAMEvent* pFilledEvent) override;
        REFERENCE_TIME Finish(CAMEvent* pFilledEvent) override;
        int64_t GetPosition() override;
        int64_t GetEnd() override;
        int64_t GetSilence() override;
        void Start() override;
        void Stop() override;
        void Reset() override;
        bool RenewInactive(const RenewBackendFunction&, int64_t& position) override;

    private:
        void Feed();
        void RenderOnePass();

        // Always acquire the stream lock before the queue lock when both are needed.
        std::mutex m_streamMutex;
        std::mutex m_queueMutex;
        std::thread m_worker;
        HANDLE m_shutdown = nullptr;
        bool m_running = false; // m_streamMutex
        bool m_endOfStream = false; // m_queueMutex
        std::atomic<bool> m_error{false};

        std::deque<DspChunk> m_queue; // m_queueMutex
        size_t m_pendingFrames = 0; // m_queueMutex
        std::atomic<uint64_t> m_receivedFrames{0};
        std::atomic<uint64_t> m_silentFrames{0};
        std::atomic<uint64_t> m_committedFrames{0};
        std::array<ISpatialAudioObjectPtr, 6> m_objects;
    };
}
