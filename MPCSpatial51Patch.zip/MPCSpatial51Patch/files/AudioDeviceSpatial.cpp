#include "pch.h"
#include "AudioDeviceSpatial.h"

#include <vector>
#include <mutex>

namespace SaneAudioRenderer
{
    namespace
    {
        constexpr unsigned kChannels = 6;
        constexpr AudioObjectType kSpeakers[kChannels] = {
            AudioObjectType_FrontLeft,
            AudioObjectType_FrontRight,
            AudioObjectType_FrontCenter,
            AudioObjectType_LowFrequency,
            AudioObjectType_SideLeft,
            AudioObjectType_SideRight,
        };
        void SpatialTrace(const wchar_t* text)
        {
            OutputDebugStringW(text);
        }
    }

    AudioDeviceSpatial::AudioDeviceSpatial(std::shared_ptr<AudioDeviceBackend> backend)
    {
        if (!backend || !backend->spatialStream || !backend->spatialEvent ||
            !backend->audioClock || backend->waveFormat->nChannels != kChannels ||
            backend->dspFormat != DspFormat::Float)
            throw HResultException{E_INVALIDARG};

        m_backend = std::move(backend);
        m_shutdown = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!m_shutdown)
            throw HResultException{HRESULT_FROM_WIN32(GetLastError())};

        try {
            m_worker = std::thread([this] { Feed(); });
        } catch (...) {
            CloseHandle(m_shutdown);
            m_shutdown = nullptr;
            throw;
        }
        SpatialTrace(L"[MPCSpatial51] spatial renderer created; six static channels selected\n");
    }

    AudioDeviceSpatial::~AudioDeviceSpatial()
    {
        if (m_shutdown)
            SetEvent(m_shutdown);
        if (m_worker.joinable())
            m_worker.join();

        {
            std::lock_guard<std::mutex> lock(m_streamMutex);
            if (m_running)
                m_backend->spatialStream->Stop();
            m_running = false;
            for (auto& o : m_objects)
                o = nullptr;
        }
        if (m_shutdown)
            CloseHandle(m_shutdown);
        SpatialTrace(L"[MPCSpatial51] spatial renderer destroyed\n");
    }

    void AudioDeviceSpatial::Push(DspChunk& chunk, CAMEvent* pFilledEvent)
    {
        if (m_error)
            throw HResultException{E_FAIL};
        if (chunk.IsEmpty()) {
            if (pFilledEvent)
                pFilledEvent->Set();
            return;
        }
        if (chunk.GetFormat() != DspFormat::Float ||
            chunk.GetChannelCount() != kChannels ||
            chunk.GetRate() != GetRate())
            throw HResultException{AUDCLNT_E_UNSUPPORTED_FORMAT};

        // Match AudioDeviceEvent: reject a full queue without consuming 'chunk'.
        {
            std::lock_guard<std::mutex> lock(m_queueMutex);
            const size_t targetFrames =
                static_cast<size_t>(m_backend->bufferDuration) * GetRate() / 1000;
            if (m_pendingFrames < targetFrames) {
                chunk.FreeMediaSample();
                const size_t count = chunk.GetFrameCount();
                m_queue.emplace_back(std::move(chunk));
                m_pendingFrames += count;
                m_receivedFrames.fetch_add(count);
            }
        }
        if (pFilledEvent && !chunk.IsEmpty())
            pFilledEvent->Set();
    }

    REFERENCE_TIME AudioDeviceSpatial::Finish(CAMEvent* pFilledEvent)
    {
        if (m_error)
            throw HResultException{E_FAIL};
        {
            std::lock_guard<std::mutex> lock(m_queueMutex);
            m_endOfStream = true;
        }
        if (pFilledEvent)
            pFilledEvent->Set();
        return std::max<int64_t>(0, GetEnd() - GetPosition());
    }

    int64_t AudioDeviceSpatial::GetPosition()
    {
        UINT64 frequency = 0, position = 0;
        ThrowIfFailed(m_backend->audioClock->GetFrequency(&frequency));
        ThrowIfFailed(m_backend->audioClock->GetPosition(&position, nullptr));
        if (!frequency)
            return 0;
        return llMulDiv(position, OneSecond, frequency, 0);
    }

    int64_t AudioDeviceSpatial::GetEnd()
    {
        return FramesToTimeLong(static_cast<int64_t>(m_receivedFrames.load()), GetRate());
    }

    int64_t AudioDeviceSpatial::GetSilence()
    {
        return FramesToTimeLong(static_cast<int64_t>(m_silentFrames.load()), GetRate());
    }

    void AudioDeviceSpatial::Start()
    {
        std::lock_guard<std::mutex> lock(m_streamMutex);
        if (m_error)
            throw HResultException{E_FAIL};
        if (!m_running) {
            ThrowIfFailed(m_backend->spatialStream->Start());
            m_running = true;
        }
    }

    void AudioDeviceSpatial::Stop()
    {
        std::lock_guard<std::mutex> lock(m_streamMutex);
        if (m_running) {
            ThrowIfFailed(m_backend->spatialStream->Stop());
            m_running = false;
        }
    }

    void AudioDeviceSpatial::Reset()
    {
        std::lock_guard<std::mutex> streamLock(m_streamMutex);
        if (m_running) {
            ThrowIfFailed(m_backend->spatialStream->Stop());
            m_running = false;
        }
        // Reset revokes existing objects. They MUST be recreated on the next pass.
        for (auto& o : m_objects)
            o = nullptr;
        ThrowIfFailed(m_backend->spatialStream->Reset());
        std::lock_guard<std::mutex> queueLock(m_queueMutex);
        m_queue.clear();
        m_pendingFrames = 0;
        m_endOfStream = false;
        m_receivedFrames = 0;
        m_silentFrames = 0;
        m_committedFrames = 0;
    }

    bool AudioDeviceSpatial::RenewInactive(const RenewBackendFunction&, int64_t& position)
    {
        // Unlike AudioDeviceEvent, this device never drops a paused backend.
        // Invalidated streams signal an error and fall back to a new device.
        position = 0;
        return !m_error.load();
    }

    void AudioDeviceSpatial::Feed()
    {
        CoInitializeHelper coinit(COINIT_MULTITHREADED);
        if (!coinit.Initialized()) {
            m_error = true;
            SpatialTrace(L"[MPCSpatial51] COM initialization failed\n");
            return;
        }

        HANDLE handles[] = {m_shutdown, m_backend->spatialEvent};
        for (;;) {
            DWORD waitResult = WaitForMultipleObjects(2, handles, FALSE, 100);
            if (waitResult == WAIT_OBJECT_0)
                break;
            if (waitResult != WAIT_OBJECT_0 + 1) {
                if (waitResult == WAIT_FAILED) {
                    m_error = true;
                    break;
                }
                continue;
            }
            try {
                std::lock_guard<std::mutex> lock(m_streamMutex);
                if (m_running)
                    RenderOnePass();
            } catch (...) {
                m_error = true;
                SpatialTrace(L"[MPCSpatial51] spatial stream failure; renderer will stop\n");
                break;
            }
        }
    }

    // Call with m_streamMutex held. Six static speaker channels, not object metadata.
    void AudioDeviceSpatial::RenderOnePass()
    {
        UINT32 availableDynamic = 0, frameCount = 0;
        ThrowIfFailed(m_backend->spatialStream->BeginUpdatingAudioObjects(
            &availableDynamic, &frameCount));
        bool ended = false;
        try {
            if (!frameCount || frameCount > GetRate())
                throw HResultException{E_FAIL};

            std::vector<float> interleaved(size_t(frameCount) * kChannels, 0.0f);
            size_t copied = 0;
            {
                std::lock_guard<std::mutex> lock(m_queueMutex);
                while (copied < frameCount && !m_queue.empty()) {
                    DspChunk& chunk = m_queue.front();
                    const size_t take = std::min<size_t>(frameCount - copied,
                                                        chunk.GetFrameCount());
                    memcpy(interleaved.data() + copied * kChannels,
                           chunk.GetData(), take * kChannels * sizeof(float));
                    copied += take;
                    m_pendingFrames -= take;
                    chunk.ShrinkHead(chunk.GetFrameCount() - take);
                    if (chunk.IsEmpty())
                        m_queue.pop_front();
                }
            }
            m_silentFrames.fetch_add(frameCount - copied);

            for (unsigned ch = 0; ch < kChannels; ++ch) {
                if (!m_objects[ch]) {
                    ISpatialAudioObject* object = nullptr;
                    ThrowIfFailed(m_backend->spatialStream->ActivateSpatialAudioObject(
                        kSpeakers[ch], &object));
                    m_objects[ch].Attach(object);
                }
                BYTE* bytes = nullptr;
                UINT32 byteCount = 0;
                ThrowIfFailed(m_objects[ch]->GetBuffer(&bytes, &byteCount));
                if (!bytes || byteCount != frameCount * sizeof(float))
                    throw HResultException{E_FAIL};
                auto* mono = reinterpret_cast<float*>(bytes);
                for (UINT32 f = 0; f < frameCount; ++f)
                    mono[f] = interleaved[size_t(f) * kChannels + ch];
            }

            ThrowIfFailed(m_backend->spatialStream->EndUpdatingAudioObjects());
            ended = true;
            const uint64_t total = m_committedFrames.fetch_add(frameCount) + frameCount;
            if (total == frameCount)
                SpatialTrace(L"[MPCSpatial51] first 5.1 spatial buffer committed to Windows\n");
        } catch (...) {
            if (!ended)
                m_backend->spatialStream->EndUpdatingAudioObjects();
            throw;
        }
    }
}
