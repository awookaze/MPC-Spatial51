#!/usr/bin/env python3
"""Generate a six-channel 48kHz 24-bit PCM Windows WAVEFORMATEXTENSIBLE 5.1(side) test.

Each channel plays a brief tone by itself. This does not establish which Windows
spatial provider is selected; the renderer's spatial-object debug log does.
"""
import math
import pathlib
import struct

OUT = pathlib.Path(__file__).resolve().parent / '5.1-side-channel-test.wav'
RATE = 48000
CHANNELS = 6
BYTES_PER_SAMPLE = 3
MASK_5POINT1_SIDE = 0x60F
DURATION_PER_CHANNEL = 0.65
GAP = 0.18
FRAMES_PER_STEP = int(RATE * (DURATION_PER_CHANNEL + GAP))
FRAMES = CHANNELS * FRAMES_PER_STEP
FREQS = [540, 600, 720, 85, 760, 830]
# Make a comfortable test: approx -21 dBFS amplitude and 20 ms fades.
AMP = 0.085


def pcm24(value: int) -> bytes:
    value = max(-8388608, min(8388607, value))
    return value.to_bytes(3, byteorder='little', signed=True)


def generate():
    # WAVE_FORMAT_EXTENSIBLE: 6ch, 24-bit integer, side-surround channel mask.
    fmt = struct.pack('<HHIIHHH', 0xFFFE, CHANNELS, RATE,
                      RATE * CHANNELS * BYTES_PER_SAMPLE,
                      CHANNELS * BYTES_PER_SAMPLE, 24, 22)
    fmt += struct.pack('<HI', 24, MASK_5POINT1_SIDE)
    fmt += bytes.fromhex('0100000000001000800000aa00389b71')
    assert len(fmt) == 40
    samples = bytearray()
    for idx in range(FRAMES):
        active = idx // FRAMES_PER_STEP
        local = idx % FRAMES_PER_STEP
        tone_frames = int(RATE * DURATION_PER_CHANNEL)
        if local < tone_frames:
            t = local / RATE
            fade = min(1.0, local / (0.02 * RATE),
                       (tone_frames - local) / (0.02 * RATE))
            level = AMP * max(0.0, fade) * math.sin(2 * math.pi * FREQS[active] * t)
        else:
            level = 0.0
        for channel in range(CHANNELS):
            samples += pcm24(round((8388607 * level) if channel == active else 0))

    riff = (b'WAVE' + b'fmt ' + struct.pack('<I', 40) + fmt +
            b'data' + struct.pack('<I', len(samples)) + samples)
    OUT.write_bytes(b'RIFF' + struct.pack('<I', len(riff)) + riff)
    print(f'Generated {OUT} ({len(samples)} bytes PCM)')


if __name__ == '__main__':
    generate()
