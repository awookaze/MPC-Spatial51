"""Static-only test for patcher anchor behavior; DOES NOT compile or run Windows code."""
import pathlib
import tempfile
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as work:
    repo = pathlib.Path(work)
    base = repo / 'src' / 'thirdparty' / 'sanear'
    (base / 'src').mkdir(parents=True)
    (base / 'src' / 'pch.h').write_text('''#include <audioclient.h>\n#include <memory>\n    _COM_SMARTPTR_TYPEDEF(IAudioClock, __uuidof(IAudioClock));\n''')
    (base / 'src' / 'AudioDevice.h').write_text('''    struct AudioDeviceBackend final\n    {\n        bool exclusive;\n    };\n''')
    (base / 'src' / 'AudioDeviceManager.cpp').write_text('''#include "AudioDevicePush.h"\n'''+
        '''        HRESULT CreateAudioDeviceBackend(IMMDeviceEnumerator* pEnumerator,\n          int x) { return 0; }\n'''+
        '''        std::shared_ptr<AudioDeviceBackend> backend;\n\n'''+
        '''        m_function = [&] { return CreateAudioDeviceBackend(m_enumerator, format, realtime, pSettings, backend); };\n''')
    (base / 'sanear.vcxproj').write_text('''<?xml version="1.0"?>\n'''+
        '''<Project>\n    <ClInclude Include="src\\AudioDeviceEvent.h" />\n'''+
        '''    <ClCompile Include="src\\AudioDeviceEvent.cpp" />\n</Project>\n''')
    r=subprocess.run([sys.executable, str(ROOT / 'apply_patch.py'),str(repo),'--dry-run'],capture_output=True,text=True)
    print('TEST DRY RUN:',r.returncode, r.stdout, r.stderr)
    assert r.returncode == 0
    result = subprocess.run([sys.executable,str(ROOT / 'apply_patch.py'),str(repo)],capture_output=True,text=True)
    assert result.returncode == 0, result.stdout+'\n'+result.stderr
    assert (base/'src'/'AudioDeviceSpatial.cpp').exists()
    ET.parse(base/'sanear.vcxproj')
    assert 'CreateSpatialAudioDeviceBackend' in (base/'src'/'AudioDeviceManager.cpp').read_text()
    assert 'ISpatialAudioClient' in (base/'src'/'pch.h').read_text()
    assert subprocess.run([sys.executable,str(ROOT/'apply_patch.py'),str(repo)],capture_output=True).returncode != 0
    print('PASS: patch anchors, patch execution, project XML, duplicate protection')

# Verify the generated 5.1 test WAV's metadata.
import struct
wave = (ROOT/'tests'/'5.1-side-channel-test.wav').read_bytes()
assert wave[:4] == b'RIFF'
assert wave[8:12] == b'WAVE'
assert struct.unpack_from('<H',wave,20)[0] == 0xFFFE
assert struct.unpack_from('<H',wave,22)[0] == 6
assert struct.unpack_from('<I',wave,24)[0] == 48000
assert struct.unpack_from('<I',wave,40)[0] == 0x60F
print('PASS: test WAV is 48kHz / 6-channel / WAVEFORMATEXTENSIBLE / 0x60F')
