#!/usr/bin/env python3
"""Apply the opt-in MPCSpatial51 experimental patch to clsid2/mpc-hc develop.

Usage: python apply_patch.py PATH_TO_MPC_HC_REPO
Does not modify the original repository without an explicit command.
Requires working tree with src/thirdparty/sanear.
"""
from __future__ import annotations
import argparse
import os
import pathlib
import shutil
import sys

HERE = pathlib.Path(__file__).resolve().parent

BACKEND_IMPL = r'''
        // Experimental spatial output for exactly 48 kHz, 5.1(side) PCM.
        // No WASAPI shared-mode stereo fallback within this backend.
        HRESULT CreateSpatialAudioDeviceBackend(IMMDeviceEnumerator* pEnumerator,
                                                 SharedWaveFormat format, bool realtime,
                                                 ISettings* pSettings,
                                                 std::shared_ptr<AudioDeviceBackend>& backend)
        {
            try
            {
                backend = std::make_shared<AudioDeviceBackend>();
                BOOL exclusive = FALSE;
                UINT32 bufferMs = 200;
                LPWSTR requestedId = nullptr;
                ThrowIfFailed(pSettings->GetOutputDevice(&requestedId, &exclusive, &bufferMs));
                std::unique_ptr<WCHAR, CoTaskMemFreeDeleter> requestedHolder(requestedId);
                if (exclusive)
                    return E_INVALIDARG;
                if (requestedId && *requestedId)
                    backend->id = std::make_shared<std::wstring>(requestedId);

                // Populates the selected/default device ID, friendly name,
                // and an ordinary *uninitialized* IAudioClient for mix-format metadata.
                CreateAudioClient(pEnumerator, *backend);
                if (!backend->audioClient || !backend->id || backend->id->empty())
                    return E_FAIL;
                WAVEFORMATEX* mixRaw = nullptr;
                ThrowIfFailed(backend->audioClient->GetMixFormat(&mixRaw));
                backend->mixFormat = SharedWaveFormat(mixRaw, CoTaskMemFreeDeleter());

                IMMDevicePtr device;
                ThrowIfFailed(pEnumerator->GetDevice(backend->id->c_str(), &device));

                ISpatialAudioClient* spatialRaw = nullptr;
                ThrowIfFailed(device->Activate(__uuidof(ISpatialAudioClient),
                                               CLSCTX_INPROC_SERVER, nullptr,
                                               reinterpret_cast<void**>(&spatialRaw)));
                backend->spatialClient.Attach(spatialRaw);

                // AudioObjectType static channels represent locations before
                // the Windows-selected headphone spatial renderer.
                constexpr AudioObjectType required = static_cast<AudioObjectType>(
                    AudioObjectType_FrontLeft | AudioObjectType_FrontRight |
                    AudioObjectType_FrontCenter | AudioObjectType_LowFrequency |
                    AudioObjectType_SideLeft | AudioObjectType_SideRight);
                AudioObjectType supported = AudioObjectType_None;
                ThrowIfFailed(backend->spatialClient->GetNativeStaticObjectTypeMask(&supported));
                if ((static_cast<UINT32>(supported) & static_cast<UINT32>(required))
                    != static_cast<UINT32>(required))
                    return AUDCLNT_E_UNSUPPORTED_FORMAT;

                WAVEFORMATEX objectFormat = {};
                objectFormat.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
                objectFormat.nChannels = 1;
                objectFormat.nSamplesPerSec = 48000;
                objectFormat.wBitsPerSample = 32;
                objectFormat.nBlockAlign = 4;
                objectFormat.nAvgBytesPerSec = 48000 * 4;
                objectFormat.cbSize = 0;
                if (backend->spatialClient->IsAudioObjectFormatSupported(&objectFormat) != S_OK)
                    return AUDCLNT_E_UNSUPPORTED_FORMAT;

                UINT32 maxFrames = 0;
                ThrowIfFailed(backend->spatialClient->GetMaxFrameCount(&objectFormat, &maxFrames));
                if (maxFrames == 0)
                    return E_FAIL;

                backend->spatialEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
                if (!backend->spatialEvent)
                    return HRESULT_FROM_WIN32(GetLastError());

                SpatialAudioObjectRenderStreamActivationParams params = {};
                params.ObjectFormat = &objectFormat;
                params.StaticObjectTypeMask = required;
                params.MinDynamicObjectCount = 0;
                params.MaxDynamicObjectCount = 0;
                params.Category = AudioCategory_Media;
                params.EventHandle = backend->spatialEvent;
                params.NotifyObject = nullptr;

                PROPVARIANT pv;
                PropVariantInit(&pv);
                pv.vt = VT_BLOB;
                pv.blob.cbSize = sizeof(params);
                pv.blob.pBlobData = reinterpret_cast<BYTE*>(&params);

                ISpatialAudioObjectRenderStream* streamRaw = nullptr;
                ThrowIfFailed(backend->spatialClient->ActivateSpatialAudioStream(
                    &pv, __uuidof(ISpatialAudioObjectRenderStream),
                    reinterpret_cast<void**>(&streamRaw)));
                backend->spatialStream.Attach(streamRaw);

                IAudioClock* clockRaw = nullptr;
                ThrowIfFailed(backend->spatialStream->GetService(
                    __uuidof(IAudioClock), reinterpret_cast<void**>(&clockRaw)));
                backend->audioClock.Attach(clockRaw);

                // Preserve the original six-channel bed all the way to the
                // spatial device. Internal DspMatrix now sees identical layouts.
                WAVEFORMATEXTENSIBLE outFormat = BuildWaveFormatExt(
                    KSDATAFORMAT_SUBTYPE_IEEE_FLOAT, 32, 32, 48000, 6,
                    KSAUDIO_SPEAKER_5POINT1_SURROUND);
                backend->waveFormat = CopyWaveFormat(outFormat.Format);
                backend->dspFormat = DspFormat::Float;
                backend->bufferDuration = std::max<UINT32>(60, bufferMs);
                backend->deviceLatency = FramesToTime(maxFrames, 48000);
                backend->deviceBufferSize = maxFrames;
                backend->spatial = true;
                backend->exclusive = false;
                backend->eventMode = true;
                backend->bitstream = false;
                backend->realtime = realtime;
                backend->ignoredSystemChannelMixer = false;
                OutputDebugStringW(L"[MPCSpatial51] ISpatialAudioClient stream ACTIVATED (5.1 static bed)\n");
                return S_OK;
            }
            catch (...) {
                backend = nullptr;
                return exception_to_hresult();
            }
        }

'''

OPT_IN = r'''
        // Opt-in only: never interfere with normal stereo or bitstream playback.
        // From a command prompt: set MPC_SPATIAL_51=1  (before launching MPC-HC).
        WCHAR enabled[8] = {};
        const bool wantsSpatial = GetEnvironmentVariableW(L"MPC_SPATIAL_51", enabled, 8) > 0 &&
                                  enabled[0] == L'1';
        if (wantsSpatial && format->nSamplesPerSec == 48000 &&
            format->nChannels == 6 &&
            DspMatrix::GetChannelMask(*format) == KSAUDIO_SPEAKER_5POINT1_SURROUND &&
            DspFormatFromWaveFormat(*format) != DspFormat::Unknown)
        {
            BOOL exclusive = FALSE;
            UINT32 bufferMs = 0;
            LPWSTR deviceId = nullptr;
            HRESULT settingsHr = pSettings->GetOutputDevice(&deviceId, &exclusive, &bufferMs);
            CoTaskMemFree(deviceId);
            if (SUCCEEDED(settingsHr) && !exclusive && !pSettings->GetCrossfeedEnabled())
            {
                m_function = [&] {
                    return CreateSpatialAudioDeviceBackend(m_enumerator, format, realtime,
                                                           pSettings, backend);
                };
                m_wake.Set();
                m_done.Wait();
                if (SUCCEEDED(m_result) && backend && backend->spatialStream)
                {
                    try {
                        return std::unique_ptr<AudioDevice>(new AudioDeviceSpatial(backend));
                    } catch (...) {
                        backend = nullptr;
                    }
                }
                OutputDebugStringW(L"[MPCSpatial51] unavailable; falling back to normal WASAPI\n");
                backend = nullptr;
            }
        }

'''


def replace_once(original: str, needle: str, replacement: str, path: pathlib.Path) -> str:
    count = original.count(needle)
    if count != 1:
        raise RuntimeError(f"{path.name}: expected one anchor, found {count}: {needle[:85]!r}")
    return original.replace(needle, replacement, 1)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo', type=pathlib.Path, help='Path to cloned clsid2/mpc-hc checkout')
    p.add_argument('--dry-run', action='store_true', help='Verify anchors, do not write')
    args = p.parse_args()
    repo = args.repo.resolve()
    root = repo / 'src' / 'thirdparty' / 'sanear'
    if not (root / 'sanear.vcxproj').is_file():
        sys.exit(f"Not a compatible MPC-HC source checkout: {root}")

    paths = {
        'pch': root / 'src' / 'pch.h',
        'backend': root / 'src' / 'AudioDevice.h',
        'manager': root / 'src' / 'AudioDeviceManager.cpp',
        'project': root / 'sanear.vcxproj',
    }
    src = {key: path.read_text(encoding='utf-8-sig') for key, path in paths.items()}
    marker = 'MPC_SPATIAL_51'
    if marker in src['manager'] or 'ISpatialAudioClientPtr' in src['pch']:
        sys.exit('Patch already applied or repository has overlapping changes. Nothing written.')

    src['pch'] = replace_once(src['pch'], '#include <audioclient.h>',
        '#include <audioclient.h>\n#include <spatialaudioclient.h>', paths['pch'])
    src['pch'] = replace_once(src['pch'],
        '    _COM_SMARTPTR_TYPEDEF(IAudioClock, __uuidof(IAudioClock));',
        '    _COM_SMARTPTR_TYPEDEF(IAudioClock, __uuidof(IAudioClock));\n'
        '    _COM_SMARTPTR_TYPEDEF(ISpatialAudioClient, __uuidof(ISpatialAudioClient));\n'
        '    _COM_SMARTPTR_TYPEDEF(ISpatialAudioObjectRenderStream, __uuidof(ISpatialAudioObjectRenderStream));\n'
        '    _COM_SMARTPTR_TYPEDEF(ISpatialAudioObject, __uuidof(ISpatialAudioObject));', paths['pch'])
    src['pch'] = replace_once(src['pch'], '#include <memory>',
        '#include <memory>\n#include <mutex>', paths['pch'])

    src['backend'] = replace_once(src['backend'], '    struct AudioDeviceBackend final\n    {',
        '    struct AudioDeviceBackend final\n    {\n'
        '        ~AudioDeviceBackend() { if (spatialEvent) CloseHandle(spatialEvent); }\n'
        '        bool spatial = false;\n'
        '        HANDLE spatialEvent = nullptr;\n'
        '        ISpatialAudioClientPtr spatialClient;\n'
        '        ISpatialAudioObjectRenderStreamPtr spatialStream;', paths['backend'])

    src['manager'] = replace_once(src['manager'], '#include "AudioDevicePush.h"',
        '#include "AudioDevicePush.h"\n#include "AudioDeviceSpatial.h"', paths['manager'])
    anchor = '''        HRESULT CreateAudioDeviceBackend(IMMDeviceEnumerator* pEnumerator,'''
    src['manager'] = replace_once(src['manager'], anchor, BACKEND_IMPL + anchor, paths['manager'])
    anchor = '''        std::shared_ptr<AudioDeviceBackend> backend;\n\n        m_function = [&] { return CreateAudioDeviceBackend(m_enumerator, format, realtime, pSettings, backend); };'''
    src['manager'] = replace_once(src['manager'], anchor,
        '        std::shared_ptr<AudioDeviceBackend> backend;\n' + OPT_IN +
        '        m_function = [&] { return CreateAudioDeviceBackend(m_enumerator, format, realtime, pSettings, backend); };',
        paths['manager'])

    src['project'] = replace_once(src['project'],
        '    <ClInclude Include="src\\AudioDeviceEvent.h" />',
        '    <ClInclude Include="src\\AudioDeviceEvent.h" />\n'
        '    <ClInclude Include="src\\AudioDeviceSpatial.h" />', paths['project'])
    src['project'] = replace_once(src['project'],
        '    <ClCompile Include="src\\AudioDeviceEvent.cpp" />',
        '    <ClCompile Include="src\\AudioDeviceEvent.cpp" />\n'
        '    <ClCompile Include="src\\AudioDeviceSpatial.cpp" />', paths['project'])

    if args.dry_run:
        print('All source anchors found; patch can be applied.')
        return

    for name in ('AudioDeviceSpatial.h', 'AudioDeviceSpatial.cpp'):
        target = root / 'src' / name
        if target.exists():
            sys.exit(f'Target already exists; refusing to change any files: {target}')
    for key, path in paths.items():
        backup = path.with_suffix(path.suffix + '.pre-spatial51')
        if backup.exists():
            sys.exit(f'Backup already exists; refusing to overwrite: {backup}')

    for key, path in paths.items():
        backup = path.with_suffix(path.suffix + '.pre-spatial51')
        shutil.copy2(path, backup)
        path.write_text(src[key], encoding='utf-8-sig' if key == 'project' else 'utf-8')
        print(f'Patched {path.relative_to(repo)}')

    for name in ('AudioDeviceSpatial.h', 'AudioDeviceSpatial.cpp'):
        target = root / 'src' / name
        if target.exists():
            sys.exit(f'Target already exists: {target}')
        shutil.copy2(HERE / 'files' / name, target)
        print(f'Added {target.relative_to(repo)}')
    print('Source patch applied. Build MPC-HC x64 Release using Visual Studio.')


if __name__ == '__main__':
    main()
